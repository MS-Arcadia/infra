A stand-in for a game build.
